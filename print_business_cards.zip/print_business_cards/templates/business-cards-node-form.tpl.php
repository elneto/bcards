<?php
drupal_add_library('system', 'jquery');

//kpr($form);

//global $theme_key;
//kpr($theme_key);

print drupal_render_children($form);

?>
  <div id="bcard-preview" data-spy="affix" data-offset-top="0">
  	<div id="marker"></div>
  	<img src="<?php print base_path() . drupal_get_path('theme', 'bootstrap_iseek'); ?>/images/un-logo-bcards.png" id="un-logo" height="50" width="59.21">
  	<div id="left-group">
  		<div class="clearfix:after"></div>
  		<span id="txt-un" class="bcard-blue">United Nations</span>
  		<div id="p-left-address-group">
  			<span id="address1">Address line 1</span>
  			<div class="clearfix:after"></div>
  			<span id="address2">Address line 2</span>
  			<div class="clearfix:after"></div>
  			<span id="city">City/State/Postaleo</span><span id="state"></span>&nbsp;<span id="zip">Zip code</span>
  			<div class="clearfix:after"></div>
  			<span id="country">Country</span>
  		</div>
  	</div>
  	<div id="right-group">
  		<span id="txt-first" class="bcard-blue">First</span>
  		<div class="clearfix:after"></div>
  		<span id="txt-last" class="bcard-blue">Last</span>
  		<div id="bc-right-column">
	  		<div id="p-right-title-group">
	  			<span id="title1">Title 1</span>
	  			<div class="clearfix:after"></div>
	  			<span id="title2">Title 2</span>
	  			<div class="clearfix:after"></div>
	  			<span id="unit1">Unit/Division/Department</span>
	  			<div class="clearfix:after"></div>
	  			<span id="unit2">Unit/Division/Department</span>
	  		</div>
	  		<div id="p-right-office-group">
	  			<span id="office">Office:</span>
	  			<div class="clearfix:after"></div>
	  			<span id="mobile">Mobile:</span>
	  			<div class="clearfix:after"></div>
	  			<span id="email">Email</span>
	  			<div class="clearfix:after"></div>
	  			<span id="fax">Fax (or social media)</span>
	  			<div class="clearfix:after"></div>
	  			<span id="url">www.un.org</span>
	  			<div class="clearfix:after"></div>
	  		</div>
	  	</div>
  	</div>
  </div>

  <div id="bcard-preview-back" data-spy="affix" data-offset-top="0">
  	<img src="<?php print base_path() . drupal_get_path('theme', 'bootstrap_iseek'); ?>/images/un-actions.png" id="un-actions" height="350" width="200">
  </div>

<script>
//Updates the text according to the input
jQuery(document).ready(function($) {
		
	//TODO: add event on lose focus?

	//get val from select
	$("#country").text($("#edit-field-address-und-0-country option:selected").text());
	
	//this adds a one time event handler to the ajax changing country select object
	$( document ).on( "focus", "select.country",function() {
		$("#"+this.id).one("change", function(){
			$("#country").text($("#"+this.id+ " option:selected").text());
		});
	});
	
	var tbl = [
			{field:"#edit-field-first-name-und-0-value",txt:"#txt-first"},
			{field:"#edit-field-last-name-und-0-value",txt:"#txt-last"},
			{field:"#edit-field-work-title-1-und-0-value",txt:"#title1"},
			{field:"#edit-field-work-title-2-und-0-value",txt:"#title2"},
			{field:"#edit-field-bc-unit-div-dep-1-und-0-value",txt:"#unit1"},
			{field:"#edit-field-bc-unit-div-dep-2-und-0-value",txt:"#unit2"},
			{field:"#edit-field-bc-office-und-0-value",txt:"#office"},
			{field:"#edit-field-mobile-und-0-value",txt:"#mobile"},
			{field:"#edit-field-e-mail-und-0-email",txt:"#email"},
			{field:"#edit-field-fax-social-media-und-0-value",txt:"#fax"},
			{field:"#edit-field-url-und-0-url",txt:"#url"},
			{field:"#edit-field-address-und-0-thoroughfare",txt:"#address1"}, //11
			{field:"#edit-field-address-und-0-premise",txt:"#address2"}, //12
			{field:"#edit-field-address-und-0-locality",txt:"#city"}, //13
			{field:"#edit-field-address-und-0-administrative-area",txt:"#state"}, //14
			{field:"#edit-field-address-und-0-postal-code",txt:"#zip"} //15
			]; 

	//populate with existing info
	$.each(tbl, function(i){
		//$(tbl[i].txt).text($(tbl[i].field).val());
		$(tbl[i].txt).text($(tbl[i].field).attr('placeholder'));
	});

	//removes submit on enter
	$('input').keypress(function (event){ return event.keyCode == 13 ? false : true; });
	
	
	$(tbl[0].field).keyup(function(){$(tbl[0].txt).text($(tbl[0].field).val());});
	$(tbl[1].field).keyup(function(){$(tbl[1].txt).text($(tbl[1].field).val());});
	$(tbl[2].field).keyup(function(){$(tbl[2].txt).text($(tbl[2].field).val());});
	$(tbl[3].field).keyup(function(){$(tbl[3].txt).text($(tbl[3].field).val());});
	$(tbl[4].field).keyup(function(){$(tbl[4].txt).text($(tbl[4].field).val());});
	$(tbl[5].field).keyup(function(){$(tbl[5].txt).text($(tbl[5].field).val());});
	$(tbl[6].field).keyup(function(){$(tbl[6].txt).text($(tbl[6].field).val());});
	$(tbl[7].field).keyup(function(){$(tbl[7].txt).text($(tbl[7].field).val());});
	$(tbl[8].field).keyup(function(){$(tbl[8].txt).text($(tbl[8].field).val());});
	$(tbl[9].field).keyup(function(){$(tbl[9].txt).text($(tbl[9].field).val());});
	$(tbl[10].field).keyup(function(){$(tbl[10].txt).text($(tbl[10].field).val());});
	$(tbl[11].field).keyup(function(){$(tbl[11].txt).text($(tbl[11].field).val());}); //the ajax updated ones
	$(tbl[12].field).keyup(function(){$(tbl[12].txt).text($(tbl[12].field).val());});
	$(tbl[13].field).keyup(function(){$(tbl[13].txt).text($(tbl[13].field).val());});
	$(tbl[14].field).keyup(function(){$(tbl[14].txt).text($(tbl[14].field).val());});
	$(tbl[15].field).keyup(function(){$(tbl[15].txt).text($(tbl[15].field).val());});

	//this adds an event handler to the ajax-changing country inputs
	$( document ).on( "focus", "input, select",function() {
		var strid = "#"+String(this.id);
		if (strid.indexOf(tbl[11].field)==0){
			$("#"+this.id).on("keyup", function(){
				$(tbl[11].txt).text($("#"+this.id).val());
			});	
		} else if (strid.indexOf(tbl[12].field)==0){
			$("#"+this.id).on("keyup", function(){
				$(tbl[12].txt).text($("#"+this.id).val());
			});	

		} else if (strid.indexOf(tbl[13].field)==0){
			$("#"+this.id).on("keyup", function(){
				$(tbl[13].txt).text($("#"+this.id).val());
			});	
		} else if (strid.indexOf(tbl[14].field)==0){
			$("#"+this.id).on("keyup change", function(){
				if ($("#"+this.id).val())
					$(tbl[14].txt).text(", "+$("#"+this.id).val());
				else
					$(tbl[14].txt).text("");
			});	
		} else if (strid.indexOf(tbl[15].field)==0){
			$("#"+this.id).on("keyup", function(){
				$(tbl[15].txt).text($("#"+this.id).val());
			});	
		} 
	});

	//add placeholder to URL field
	$("#edit-field-url-und-0-url").attr('placeholder', 'www.un.org');

	//vertical / horizontal layout
	$("#edit-field-orientation-und-0").change(function(){ //horizontal
		$("#bcard-preview").css({width:"200px",height:"350px"}).animate({width:"350px",height:"200px", right:"3em"});
		$("#un-logo").animate({left:"19.22px",top:"18px"});
		$("#right-group").animate({left:"143.2px",top:"30.5px"});
		$("#txt-un").animate({left:"19.22px",top:"80.97px"});
		$("#left-group").animate({"margin-left":"19.22px","margin-top":"0"});

		$("#bcard-preview-back").css({width:"200px",height:"350px"}).animate({width:"350px",height:"200px", top:"30em"});
		$("#un-actions").css({"transform": "rotate(-90deg)", "margin-top":"200px"});
	});

	$("#edit-field-orientation-und-1").change(function(){ //vertical
		$("#bcard-preview").animate({width:"200px",height:"350px",right:"19em"});
		//$("#bcard-preview").height(350).width(200);
		$("#un-logo").animate({left:"18px",top:"17px"});
		$("#right-group").animate({left:"18px",top:"80px"});
		$("#txt-un").animate({left:"18px",top:"251px"});
		$("#left-group").animate({"margin-left":"18px","margin-top":"165px"});

		$("#bcard-preview-back").animate({width:"200px",height:"350px", top:"13em"});
		$("#un-actions").css({"transform": "rotate(0)", "margin-top":"0"});
	});

	$("#edit-field-back-image-und-0").change(function(){ //blank
		$("#un-actions").animate({opacity:0});
	});

	$("#edit-field-back-image-und-1").change(function(){ //UN Actions
		$("#un-actions").animate({opacity:1});
	});


});
</script>
 <?php

